module {
	func.func @sdsc_bundle() {
		%sym_1 = arith.constant 17179869184 : index
		%sym_2 = arith.constant 34359738368 : index
		%sym_3 = arith.constant 34359934976 : index
		%sym_4 = arith.constant 34360131584 : index
		%sym_5 = arith.constant 34360328192 : index
		%sym_6 = arith.constant 34360524800 : index
		%sym_7 = arith.constant 34360721408 : index
		%sym_8 = arith.constant 34360918016 : index
		%sym_9 = arith.constant 34361114624 : index
		%sym_10 = arith.constant 34361311232 : index
		%sym_11 = arith.constant 34361507840 : index
		%sym_12 = arith.constant 34361704448 : index
		%sym_13 = arith.constant 34361901056 : index
		%sym_14 = arith.constant 34362097664 : index
		%sym_15 = arith.constant 34362294272 : index
		%sym_16 = arith.constant 34362490880 : index
		%sym_17 = arith.constant 34362687488 : index
		%sym_18 = arith.constant 34362884096 : index
		%sym_19 = arith.constant 34363080704 : index
		%sym_20 = arith.constant 34363277312 : index
		%sym_21 = arith.constant 34363473920 : index
		%sym_22 = arith.constant 34363670528 : index
		%sym_23 = arith.constant 34363867136 : index
		%sym_24 = arith.constant 34364063744 : index
		%sym_25 = arith.constant 34364260352 : index
		%sym_26 = arith.constant 34364456960 : index
		%sym_27 = arith.constant 34364653568 : index
		%sym_28 = arith.constant 34364850176 : index
		%sym_29 = arith.constant 34365046784 : index
		%sym_30 = arith.constant 34365243392 : index
		%sym_31 = arith.constant 34365440000 : index
		%sym_32 = arith.constant 34365636608 : index
		%sym_33 = arith.constant 34365833216 : index
		%sym_34 = arith.constant 51539607552 : index
		%sym_35 = arith.constant 34359746560 : index
		%sym_36 = arith.constant 34359943168 : index
		%sym_37 = arith.constant 34360139776 : index
		%sym_38 = arith.constant 34360336384 : index
		%sym_39 = arith.constant 34360532992 : index
		%sym_40 = arith.constant 34360729600 : index
		%sym_41 = arith.constant 34360926208 : index
		%sym_42 = arith.constant 34361122816 : index
		%sym_43 = arith.constant 34361319424 : index
		%sym_44 = arith.constant 34361516032 : index
		%sym_45 = arith.constant 34361712640 : index
		%sym_46 = arith.constant 34361909248 : index
		%sym_47 = arith.constant 34362105856 : index
		%sym_48 = arith.constant 34362302464 : index
		%sym_49 = arith.constant 34362499072 : index
		%sym_50 = arith.constant 34362695680 : index
		%sym_51 = arith.constant 34362892288 : index
		%sym_52 = arith.constant 34363088896 : index
		%sym_53 = arith.constant 34363285504 : index
		%sym_54 = arith.constant 34363482112 : index
		%sym_55 = arith.constant 34363678720 : index
		%sym_56 = arith.constant 34363875328 : index
		%sym_57 = arith.constant 34364071936 : index
		%sym_58 = arith.constant 34364268544 : index
		%sym_59 = arith.constant 34364465152 : index
		%sym_60 = arith.constant 34364661760 : index
		%sym_61 = arith.constant 34364858368 : index
		%sym_62 = arith.constant 34365054976 : index
		%sym_63 = arith.constant 34365251584 : index
		%sym_64 = arith.constant 34365448192 : index
		%sym_65 = arith.constant 34365644800 : index
		%sym_66 = arith.constant 34365841408 : index
		%sym_67 = arith.constant 85899345920 : index
		%sym_68 = arith.constant 85899347968 : index
		%sym_69 = arith.constant 85899350016 : index
		%sym_70 = arith.constant 85899352064 : index
		%sym_71 = arith.constant 85899354112 : index
		%sym_72 = arith.constant 85899356160 : index
		%sym_73 = arith.constant 85899358208 : index
		%sym_74 = arith.constant 85899360256 : index
		%sym_75 = arith.constant 85899362304 : index
		%sym_76 = arith.constant 85899364352 : index
		%sym_77 = arith.constant 85899366400 : index
		%sym_78 = arith.constant 85899368448 : index
		%sym_79 = arith.constant 85899370496 : index
		%sym_80 = arith.constant 85899372544 : index
		%sym_81 = arith.constant 85899374592 : index
		%sym_82 = arith.constant 85899376640 : index
		%sym_83 = arith.constant 85899378688 : index
		%sym_84 = arith.constant 85899380736 : index
		%sym_85 = arith.constant 85899382784 : index
		%sym_86 = arith.constant 85899384832 : index
		%sym_87 = arith.constant 85899386880 : index
		%sym_88 = arith.constant 85899388928 : index
		%sym_89 = arith.constant 85899390976 : index
		%sym_90 = arith.constant 85899393024 : index
		%sym_91 = arith.constant 85899395072 : index
		%sym_92 = arith.constant 85899397120 : index
		%sym_93 = arith.constant 85899399168 : index
		%sym_94 = arith.constant 85899401216 : index
		%sym_95 = arith.constant 85899403264 : index
		%sym_96 = arith.constant 85899405312 : index
		%sym_97 = arith.constant 85899407360 : index
		%sym_98 = arith.constant 85899409408 : index
		%sym_99 = arith.constant 51539607552 : index
		%sym_100 = arith.constant 4194304 : index
		%sym_101 = arith.constant 4227072 : index
		%sym_102 = arith.constant 4259840 : index
		%sym_103 = arith.constant 4292608 : index
		%sym_104 = arith.constant 4325376 : index
		%sym_105 = arith.constant 4358144 : index
		%sym_106 = arith.constant 4390912 : index
		%sym_107 = arith.constant 4423680 : index
		%sym_108 = arith.constant 4456448 : index
		%sym_109 = arith.constant 4489216 : index
		%sym_110 = arith.constant 4521984 : index
		%sym_111 = arith.constant 4554752 : index
		%sym_112 = arith.constant 4587520 : index
		%sym_113 = arith.constant 4620288 : index
		%sym_114 = arith.constant 4653056 : index
		%sym_115 = arith.constant 4685824 : index
		%sym_116 = arith.constant 4194816 : index
		%sym_117 = arith.constant 4227584 : index
		%sym_118 = arith.constant 4260352 : index
		%sym_119 = arith.constant 4293120 : index
		%sym_120 = arith.constant 4325888 : index
		%sym_121 = arith.constant 4358656 : index
		%sym_122 = arith.constant 4391424 : index
		%sym_123 = arith.constant 4424192 : index
		%sym_124 = arith.constant 4456960 : index
		%sym_125 = arith.constant 4489728 : index
		%sym_126 = arith.constant 4522496 : index
		%sym_127 = arith.constant 4555264 : index
		%sym_128 = arith.constant 4588032 : index
		%sym_129 = arith.constant 4620800 : index
		%sym_130 = arith.constant 4653568 : index
		%sym_131 = arith.constant 4686336 : index
		%sym_132 = arith.constant 4194304 : index
		%sym_133 = arith.constant 4210688 : index
		%sym_134 = arith.constant 4227072 : index
		%sym_135 = arith.constant 4243456 : index
		%sym_136 = arith.constant 4259840 : index
		%sym_137 = arith.constant 4276224 : index
		%sym_138 = arith.constant 4292608 : index
		%sym_139 = arith.constant 4308992 : index
		%sym_140 = arith.constant 4325376 : index
		%sym_141 = arith.constant 4341760 : index
		%sym_142 = arith.constant 4358144 : index
		%sym_143 = arith.constant 4374528 : index
		%sym_144 = arith.constant 4390912 : index
		%sym_145 = arith.constant 4407296 : index
		%sym_146 = arith.constant 4423680 : index
		%sym_147 = arith.constant 4440064 : index
		%sym_148 = arith.constant 4456448 : index
		%sym_149 = arith.constant 4472832 : index
		%sym_150 = arith.constant 4489216 : index
		%sym_151 = arith.constant 4505600 : index
		%sym_152 = arith.constant 4521984 : index
		%sym_153 = arith.constant 4538368 : index
		%sym_154 = arith.constant 4554752 : index
		%sym_155 = arith.constant 4571136 : index
		%sym_156 = arith.constant 4587520 : index
		%sym_157 = arith.constant 4603904 : index
		%sym_158 = arith.constant 4620288 : index
		%sym_159 = arith.constant 4636672 : index
		%sym_160 = arith.constant 4653056 : index
		%sym_161 = arith.constant 4669440 : index
		%sym_162 = arith.constant 4685824 : index
		%sym_163 = arith.constant 4702208 : index
		%sym_164 = arith.constant 68719476736 : index
		%sym_165 = arith.constant 68719493120 : index
		%sym_166 = arith.constant 68719509504 : index
		%sym_167 = arith.constant 68719525888 : index
		%sym_168 = arith.constant 68719542272 : index
		%sym_169 = arith.constant 68719558656 : index
		%sym_170 = arith.constant 68719575040 : index
		%sym_171 = arith.constant 68719591424 : index
		%sym_172 = arith.constant 68719607808 : index
		%sym_173 = arith.constant 68719624192 : index
		%sym_174 = arith.constant 68719640576 : index
		%sym_175 = arith.constant 68719656960 : index
		%sym_176 = arith.constant 68719673344 : index
		%sym_177 = arith.constant 68719689728 : index
		%sym_178 = arith.constant 68719706112 : index
		%sym_179 = arith.constant 68719722496 : index
		%sym_180 = arith.constant 68719738880 : index
		%sym_181 = arith.constant 68719755264 : index
		%sym_182 = arith.constant 68719771648 : index
		%sym_183 = arith.constant 68719788032 : index
		%sym_184 = arith.constant 68719804416 : index
		%sym_185 = arith.constant 68719820800 : index
		%sym_186 = arith.constant 68719837184 : index
		%sym_187 = arith.constant 68719853568 : index
		%sym_188 = arith.constant 68719869952 : index
		%sym_189 = arith.constant 68719886336 : index
		%sym_190 = arith.constant 68719902720 : index
		%sym_191 = arith.constant 68719919104 : index
		%sym_192 = arith.constant 68719935488 : index
		%sym_193 = arith.constant 68719951872 : index
		%sym_194 = arith.constant 68719968256 : index
		%sym_195 = arith.constant 68719984640 : index
		%sym_196 = arith.constant 34359748608 : index
		%sym_197 = arith.constant 34359945216 : index
		%sym_198 = arith.constant 34360141824 : index
		%sym_199 = arith.constant 34360338432 : index
		%sym_200 = arith.constant 34360535040 : index
		%sym_201 = arith.constant 34360731648 : index
		%sym_202 = arith.constant 34360928256 : index
		%sym_203 = arith.constant 34361124864 : index
		%sym_204 = arith.constant 34361321472 : index
		%sym_205 = arith.constant 34361518080 : index
		%sym_206 = arith.constant 34361714688 : index
		%sym_207 = arith.constant 34361911296 : index
		%sym_208 = arith.constant 34362107904 : index
		%sym_209 = arith.constant 34362304512 : index
		%sym_210 = arith.constant 34362501120 : index
		%sym_211 = arith.constant 34362697728 : index
		%sym_212 = arith.constant 34362894336 : index
		%sym_213 = arith.constant 34363090944 : index
		%sym_214 = arith.constant 34363287552 : index
		%sym_215 = arith.constant 34363484160 : index
		%sym_216 = arith.constant 34363680768 : index
		%sym_217 = arith.constant 34363877376 : index
		%sym_218 = arith.constant 34364073984 : index
		%sym_219 = arith.constant 34364270592 : index
		%sym_220 = arith.constant 34364467200 : index
		%sym_221 = arith.constant 34364663808 : index
		%sym_222 = arith.constant 34364860416 : index
		%sym_223 = arith.constant 34365057024 : index
		%sym_224 = arith.constant 34365253632 : index
		%sym_225 = arith.constant 34365450240 : index
		%sym_226 = arith.constant 34365646848 : index
		%sym_227 = arith.constant 34365843456 : index
		sdscbundle.sdsc_execute (%sym_1) {sdsc_filename="sdsc_0.json", "symbol_ids"=[-1]}
		sdscbundle.sdsc_execute (%sym_2, %sym_3, %sym_4, %sym_5, %sym_6, %sym_7, %sym_8, %sym_9, %sym_10, %sym_11, %sym_12, %sym_13, %sym_14, %sym_15, %sym_16, %sym_17, %sym_18, %sym_19, %sym_20, %sym_21, %sym_22, %sym_23, %sym_24, %sym_25, %sym_26, %sym_27, %sym_28, %sym_29, %sym_30, %sym_31, %sym_32, %sym_33) {sdsc_filename="sdsc_1.json", "symbol_ids"=[-2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, -16, -17, -18, -19, -20, -21, -22, -23, -24, -25, -26, -27, -28, -29, -30, -31, -32, -33]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_2.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute (%sym_34) {sdsc_filename="sdsc_3.json", "symbol_ids"=[-34]}
		sdscbundle.sdsc_execute (%sym_35, %sym_36, %sym_37, %sym_38, %sym_39, %sym_40, %sym_41, %sym_42, %sym_43, %sym_44, %sym_45, %sym_46, %sym_47, %sym_48, %sym_49, %sym_50, %sym_51, %sym_52, %sym_53, %sym_54, %sym_55, %sym_56, %sym_57, %sym_58, %sym_59, %sym_60, %sym_61, %sym_62, %sym_63, %sym_64, %sym_65, %sym_66) {sdsc_filename="sdsc_4.json", "symbol_ids"=[-35, -36, -37, -38, -39, -40, -41, -42, -43, -44, -45, -46, -47, -48, -49, -50, -51, -52, -53, -54, -55, -56, -57, -58, -59, -60, -61, -62, -63, -64, -65, -66]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_5.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute (%sym_67, %sym_68, %sym_69, %sym_70, %sym_71, %sym_72, %sym_73, %sym_74, %sym_75, %sym_76, %sym_77, %sym_78, %sym_79, %sym_80, %sym_81, %sym_82, %sym_83, %sym_84, %sym_85, %sym_86, %sym_87, %sym_88, %sym_89, %sym_90, %sym_91, %sym_92, %sym_93, %sym_94, %sym_95, %sym_96, %sym_97, %sym_98) {sdsc_filename="sdsc_6.json", "symbol_ids"=[-67, -68, -69, -70, -71, -72, -73, -74, -75, -76, -77, -78, -79, -80, -81, -82, -83, -84, -85, -86, -87, -88, -89, -90, -91, -92, -93, -94, -95, -96, -97, -98]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_7.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute (%sym_99) {sdsc_filename="sdsc_8.json", "symbol_ids"=[-99]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_9.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute (%sym_100, %sym_101, %sym_102, %sym_103, %sym_104, %sym_105, %sym_106, %sym_107, %sym_108, %sym_109, %sym_110, %sym_111, %sym_112, %sym_113, %sym_114, %sym_115, %sym_116, %sym_117, %sym_118, %sym_119, %sym_120, %sym_121, %sym_122, %sym_123, %sym_124, %sym_125, %sym_126, %sym_127, %sym_128, %sym_129, %sym_130, %sym_131) {sdsc_filename="sdsc_10.json", "symbol_ids"=[-100, -101, -102, -103, -104, -105, -106, -107, -108, -109, -110, -111, -112, -113, -114, -115, -116, -117, -118, -119, -120, -121, -122, -123, -124, -125, -126, -127, -128, -129, -130, -131]}
		sdscbundle.sdsc_execute (%sym_132, %sym_133, %sym_134, %sym_135, %sym_136, %sym_137, %sym_138, %sym_139, %sym_140, %sym_141, %sym_142, %sym_143, %sym_144, %sym_145, %sym_146, %sym_147, %sym_148, %sym_149, %sym_150, %sym_151, %sym_152, %sym_153, %sym_154, %sym_155, %sym_156, %sym_157, %sym_158, %sym_159, %sym_160, %sym_161, %sym_162, %sym_163, %sym_164, %sym_165, %sym_166, %sym_167, %sym_168, %sym_169, %sym_170, %sym_171, %sym_172, %sym_173, %sym_174, %sym_175, %sym_176, %sym_177, %sym_178, %sym_179, %sym_180, %sym_181, %sym_182, %sym_183, %sym_184, %sym_185, %sym_186, %sym_187, %sym_188, %sym_189, %sym_190, %sym_191, %sym_192, %sym_193, %sym_194, %sym_195) {sdsc_filename="sdsc_11.json", "symbol_ids"=[-132, -133, -134, -135, -136, -137, -138, -139, -140, -141, -142, -143, -144, -145, -146, -147, -148, -149, -150, -151, -152, -153, -154, -155, -156, -157, -158, -159, -160, -161, -162, -163, -164, -165, -166, -167, -168, -169, -170, -171, -172, -173, -174, -175, -176, -177, -178, -179, -180, -181, -182, -183, -184, -185, -186, -187, -188, -189, -190, -191, -192, -193, -194, -195]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_12.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_13.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_14.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_15.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_16.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute (%sym_196, %sym_197, %sym_198, %sym_199, %sym_200, %sym_201, %sym_202, %sym_203, %sym_204, %sym_205, %sym_206, %sym_207, %sym_208, %sym_209, %sym_210, %sym_211, %sym_212, %sym_213, %sym_214, %sym_215, %sym_216, %sym_217, %sym_218, %sym_219, %sym_220, %sym_221, %sym_222, %sym_223, %sym_224, %sym_225, %sym_226, %sym_227) {sdsc_filename="sdsc_17.json", "symbol_ids"=[-196, -197, -198, -199, -200, -201, -202, -203, -204, -205, -206, -207, -208, -209, -210, -211, -212, -213, -214, -215, -216, -217, -218, -219, -220, -221, -222, -223, -224, -225, -226, -227]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_18.json", "symbol_ids"=[]}
		sdscbundle.sdsc_execute () {sdsc_filename="sdsc_19.json", "symbol_ids"=[]}
		return
	}
}
