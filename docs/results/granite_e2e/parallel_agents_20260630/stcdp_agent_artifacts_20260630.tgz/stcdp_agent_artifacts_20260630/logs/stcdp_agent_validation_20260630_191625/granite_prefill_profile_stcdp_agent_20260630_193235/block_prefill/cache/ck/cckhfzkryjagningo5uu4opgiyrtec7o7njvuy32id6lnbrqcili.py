# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from sympy import sympify
from torch_spyre._inductor.op_spec import TensorArg, OpSpec, UnimplementedOp, LoopSpec, spyre_constant_tensor, IndirectAccess
from torch_spyre.execution.async_compile import SpyreAsyncCompile
from torch_spyre._C import DataFormats, SpyreTensorLayout, spyre_empty_with_layout
import subprocess

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p
from torch_spyre._C import reinterpret_tensor as reinterpret_tensor
from torch_spyre._C import reinterpret_tensor_with_layout
del async_compile
async_compile = SpyreAsyncCompile()


# Topologically Sorted Source Nodes: [x, linear], Original ATen: [aten.rms_norm, aten.linear]
# Source node to ATen node mapping:
#   linear => bmm, permute, unsqueeze, view_1
#   x => add, mean, mul, mul_1, mul_2, rsqrt
# Graph fragment:
#   %arg1_1 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=arg1_1]
#   %clone_4 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=clone_4]
#   %mul : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=mul]
#   %mean : Tensor "f16[1, 512, 1][512, 1, 512]spyre:0" = PlaceHolder[target=mean]
#   %constant_default : Tensor "f16[][]spyre:0" = PlaceHolder[target=constant_default]
#   %add : Tensor "f16[1, 512, 1][512, 1, 512]spyre:0" = PlaceHolder[target=add]
#   %rsqrt : Tensor "f16[1, 512, 1][512, 1, 512]spyre:0" = PlaceHolder[target=rsqrt]
#   %mul_1 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=mul_1]
#   %arg0_1 : Tensor "f16[4096][1]spyre:0" = PlaceHolder[target=arg0_1]
#   %arg2_1 : Tensor "f16[6144, 4096][4096, 1]spyre:0" = PlaceHolder[target=arg2_1]
#   %view : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=view]
#   %restickify_default : Tensor "f16[6144, 4096][4096, 1]spyre:0" = PlaceHolder[target=restickify_default]
#   %clone_4 : [num_users=3] = call_function[target=torch.ops.aten.clone](args = (%arg1_1,), kwargs = {})
#   %restickify_default : [num_users=0] = call_function[target=torch.ops.spyre.restickify.default](args = (%arg2_1,), kwargs = {})
#   %mul : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %clone_4), kwargs = {})
#   %mean : Tensor "f16[1, 512, 1][512, 1, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%mul, [-1], True), kwargs = {})
#   %add : Tensor "f16[1, 512, 1][512, 1, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-05), kwargs = {})
#   %rsqrt : Tensor "f16[1, 512, 1][512, 1, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul_1 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %rsqrt), kwargs = {})
#   %mul_2 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_1, %arg0_1), kwargs = {})
#   %permute : Tensor "f16[4096, 6144][1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg2_1, [1, 0]), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 4096, 6144][4096, 1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 0), kwargs = {})
#   %view_1 : Tensor "f16[1, 4096, 6144][4096, 1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_1, [1, 4096, 6144]), kwargs = {})
#   %bmm : Tensor "f16[1, 512, 6144][3145728, 6144, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view, %view_1), kwargs = {})
#   return %clone_4,%mul,%mean,%add,%rsqrt,%mul_1,%view,%restickify_default,%buf6
sdsc_fused_linear_rms_norm_0 = async_compile.sdsc('sdsc_fused_linear_rms_norm_0',
    [
        OpSpec(
            op='identity',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=0, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 17179869184},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='mean',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={'constants': {'scaling_factor': 0.000244140625}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
            ]
        ),
        OpSpec(
            op='add',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=True, arg_index=1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 64],
                    device_coordinates=[sympify('0'), sympify('0'), sympify('0')],
                    allocation={'hbm': 34359738368},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
            ]
        ),
        OpSpec(
            op='rsqrt',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=2, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 64, 64],
                    device_coordinates=[sympify('0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 51539607552},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 0},
                ),
            ]
        ),
        OpSpec(
            op='ReStickifyOpHBM',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('6144'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=3, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 6144, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 68719476736},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[96, 4096, 64],
                    device_coordinates=[sympify('floor(c0/64)'), sympify('c1'), sympify('Mod(c0, 64)')],
                    allocation={'pool': 4194304},
                ),
            ]
        ),
        OpSpec(
            op='batchmatmul',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 4), sympify('c1'): (sympify('6144'), 8), sympify('c2'): (sympify('4096'), 1)},
            op_info={'lx_relayout_classifications': {'buf5': {'source_name': 'buf5', 'producer_name': 'buf5', 'consumer_name': 'buf6', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'2': 0}, '1': {'2': 1}, '2': {'2': 2}, '3': {'2': 3}, '4': {'2': 4}, '5': {'2': 5}, '6': {'2': 6}, '7': {'2': 7}, '8': {'2': 8}, '9': {'2': 9}, '10': {'2': 10}, '11': {'2': 11}, '12': {'2': 12}, '13': {'2': 13}, '14': {'2': 14}, '15': {'2': 15}, '16': {'2': 16}, '17': {'2': 17}, '18': {'2': 18}, '19': {'2': 19}, '20': {'2': 20}, '21': {'2': 21}, '22': {'2': 22}, '23': {'2': 23}, '24': {'2': 24}, '25': {'2': 25}, '26': {'2': 26}, '27': {'2': 27}, '28': {'2': 28}, '29': {'2': 29}, '30': {'2': 30}, '31': {'2': 31}}, 'producer_work_slice_dims': {'2': 32}, 'consumer_work_slice_dims': {'2': 4}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}, 'buf45': {'source_name': 'buf45', 'producer_name': 'buf45', 'consumer_name': 'buf6', 'kind': 'layout_restickify_weight', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}, '25': {'0': 25}, '26': {'0': 26}, '27': {'0': 27}, '28': {'0': 28}, '29': {'0': 29}, '30': {'0': 30}, '31': {'0': 31}}, 'producer_work_slice_dims': {'0': 32}, 'consumer_work_slice_dims': {'0': 8}, 'read_index': 1, 'realized': False, 'communication_pattern': 'offline_weight_prelayout', 'unsupported_reason': 'graph-input/parameter restickify is owned by offline weight prelayout, not runtime LX relayout'}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 512, 64],
                    device_coordinates=[sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'pool': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[96, 4096, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c2'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 4194304},
                ),
                TensorArg(
                    is_input=False, arg_index=4, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 96, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 85899345920},
                ),
            ]
        ),
    ]
)


# Topologically Sorted Source Nodes: [split, getitem_3, queries, q_, unsqueeze, mul, sum_1, q_out_1, q_out_2, queries_1, attn, getitem_4, keys, k_, unsqueeze_1, mul_1, sum_2, k_out_1, k_out_2, keys_1, unsqueeze_3, expand, keys_e, mask, values, values_1, unsqueeze_4, expand_1, values_e], Original ATen: [aten.split_with_sizes, aten.unsqueeze, aten.view, aten.mul, aten.sum, aten.transpose, aten._scaled_dot_product_fused_attention_overrideable, aten.expand, aten.clone, aten._unsafe_view]
# Source node to ATen node mapping:
#   attn => add_1, amax, clone_2, div, exp, mul_5, mul_6, permute_4, permute_5, sub, sum_3
#   expand => expand_2
#   expand_1 => expand_3
#   getitem_3 => unsqueeze_1
#   getitem_4 => unsqueeze_3
#   k_ => view_7
#   k_out_1 => view_9
#   k_out_2 => view_11
#   keys => view_4
#   keys_1 => permute_1
#   keys_e => clone, view_12
#   mask => unsqueeze_5
#   mul => mul_3
#   mul_1 => mul_4
#   q_ => view_6
#   q_out_1 => view_8
#   q_out_2 => view_10
#   queries => view_3
#   queries_1 => permute_3
#   split => split_with_sizes
#   sum_1 => sum_1
#   sum_2 => sum_2
#   unsqueeze => unsqueeze_2
#   unsqueeze_1 => unsqueeze_4
#   unsqueeze_3 => unsqueeze_6
#   unsqueeze_4 => unsqueeze_7
#   values => view_5
#   values_1 => permute_2
#   values_e => clone_1, view_13
# Graph fragment:
#   %arg3_1 : Tensor "f16[1, 512, 2, 2, 64][131072, 256, 128, 64, 1]spyre:0" = PlaceHolder[target=arg3_1]
#   %clone_5 : Tensor "f16[1, 512, 2, 2, 64][131072, 256, 128, 64, 1]spyre:0" = PlaceHolder[target=clone_5]
#   %buf6 : Tensor "f16[1, 512, 6144][3145728, 6144, 1]spyre:0" = PlaceHolder[target=buf6]
#   %mul_3 : Tensor "f16[1, 512, 32, 2, 2, 64][4194304, 8192, 256, 128, 64, 1]spyre:0" = PlaceHolder[target=mul_3]
#   %sum_1 : Tensor "f16[1, 512, 32, 2, 1, 64][2097152, 4096, 128, 64, 64, 1]spyre:0" = PlaceHolder[target=sum_1]
#   %constant_default_1 : Tensor "f16[][]spyre:0" = PlaceHolder[target=constant_default_1]
#   %mul_4 : Tensor "f16[1, 512, 8, 2, 2, 64][1048576, 2048, 256, 128, 64, 1]spyre:0" = PlaceHolder[target=mul_4]
#   %sum_2 : Tensor "f16[1, 512, 8, 2, 1, 64][524288, 1024, 128, 64, 64, 1]spyre:0" = PlaceHolder[target=sum_2]
#   %clone : Tensor "f16[1, 8, 4, 512, 128][2097152, 262144, 65536, 128, 1]spyre:0" = PlaceHolder[target=clone]
#   %mul_6 : Tensor "f16[1, 32, 512, 128][2097152, 65536, 128, 1]spyre:0" = PlaceHolder[target=mul_6]
#   %expand_4 : Tensor "f16[1, 32, 512, 128][2097152, 128, 4096, 1]spyre:0" = PlaceHolder[target=expand_4]
#   %restickify_default_1 : Tensor "f16[1, 32, 512, 128][2097152, 65536, 128, 1]spyre:0" = PlaceHolder[target=restickify_default_1]
#   %buf14 : Tensor "f16[1, 32, 512, 512][8388608, 512, 16384, 1]spyre:0" = PlaceHolder[target=buf14]
#   %arg4_1 : Tensor "f16[1, 512, 512][262144, 512, 1]spyre:0" = PlaceHolder[target=arg4_1]
#   %add_1 : Tensor "f16[1, 32, 512, 512][8388608, 512, 16384, 1]spyre:0" = PlaceHolder[target=add_1]
#   %amax : Tensor "f16[1, 32, 512, 1][16384, 512, 1, 16384]spyre:0" = PlaceHolder[target=amax]
#   %sub : Tensor "f16[1, 32, 512, 512][8388608, 262144, 512, 1]spyre:0" = PlaceHolder[target=sub]
#   %exp : Tensor "f16[1, 32, 512, 512][8388608, 262144, 512, 1]spyre:0" = PlaceHolder[target=exp]
#   %sum_3 : Tensor "f16[1, 32, 512, 1][16384, 512, 1, 16384]spyre:0" = PlaceHolder[target=sum_3]
#   %expand_6 : Tensor "f16[1, 32, 512, 512][8388608, 262144, 512, 1]spyre:0" = PlaceHolder[target=expand_6]
#   %clone_1 : Tensor "f16[1, 8, 4, 512, 128][2097152, 262144, 65536, 128, 1]spyre:0" = PlaceHolder[target=clone_1]
#   %batched_matmul_default : Tensor "f16[1, 32, 512, 128][2097152, 65536, 128, 1]spyre:0" = PlaceHolder[target=batched_matmul_default]
#   %clone_5 : [num_users=2] = call_function[target=torch.ops.aten.clone](args = (%arg3_1,), kwargs = {})
#   %restickify_default_1 : [num_users=0] = call_function[target=torch.ops.spyre.restickify.default](args = (%mul_6,), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%view_2, [4096, 1024, 1024], -1), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 512, 1, 2, 2, 64][131072, 256, 256, 128, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%clone_5, 2), kwargs = {})
#   %view_3 : Tensor "f16[1, 512, 32, 128][3145728, 6144, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem, [1, 512, 32, 128]), kwargs = {})
#   %view_6 : Tensor "f16[1, 512, 32, 2, 64][3145728, 6144, 128, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_3, [1, 512, 32, 2, -1]), kwargs = {})
#   %unsqueeze_2 : Tensor "f16[1, 512, 32, 1, 2, 64][3145728, 6144, 128, 128, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_6, -3), kwargs = {})
#   %mul_3 : Tensor "f16[1, 512, 32, 2, 2, 64][4194304, 8192, 256, 128, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_1, %unsqueeze_2), kwargs = {})
#   %sum_1 : Tensor "f16[1, 512, 32, 2, 1, 64][2097152, 4096, 128, 64, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_3, [4], True), kwargs = {})
#   %view_8 : Tensor "f16[1, 512, 32, 128][2097152, 4096, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%sum_1, [1, 512, 32, 128]), kwargs = {})
#   %view_10 : Tensor "f16[1, 512, 32, 128][2097152, 4096, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_8, [1, 512, 32, 128]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 32, 512, 128][2097152, 128, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_10, [0, 2, 1, 3]), kwargs = {})
#   %mul_5 : Tensor "f16[1, 32, 512, 128][2097152, 128, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, 0.08838834764831845), kwargs = {})
#   %unsqueeze_3 : Tensor "f16[1, 512, 1, 2, 2, 64][131072, 256, 256, 128, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%clone_5, 2), kwargs = {})
#   %view_4 : Tensor "f16[1, 512, 8, 128][3145728, 6144, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_1, [1, 512, 8, 128]), kwargs = {})
#   %view_7 : Tensor "f16[1, 512, 8, 2, 64][3145728, 6144, 128, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 512, 8, 2, -1]), kwargs = {})
#   %unsqueeze_4 : Tensor "f16[1, 512, 8, 1, 2, 64][3145728, 6144, 128, 128, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_7, -3), kwargs = {})
#   %mul_4 : Tensor "f16[1, 512, 8, 2, 2, 64][1048576, 2048, 256, 128, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_3, %unsqueeze_4), kwargs = {})
#   %sum_2 : Tensor "f16[1, 512, 8, 2, 1, 64][524288, 1024, 128, 64, 64, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_4, [4], True), kwargs = {})
#   %clone_3 : [num_users=1] = call_function[target=torch.ops.aten.clone](args = (%sum_2,), kwargs = {})
#   %view_9 : Tensor "f16[1, 512, 8, 128][524288, 1024, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_3, [1, 512, 8, 128]), kwargs = {})
#   %view_11 : Tensor "f16[1, 512, 8, 128][524288, 1024, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_9, [1, 512, 8, 128]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 8, 512, 128][524288, 128, 1024, 1]spyre:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_11, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze_6 : Tensor "f16[1, 8, 1, 512, 128][524288, 128, 524288, 1024, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_1, 2), kwargs = {})
#   %expand_2 : Tensor "f16[1, 8, 4, 512, 128][524288, 128, 0, 1024, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [-1, -1, 4, -1, -1]), kwargs = {})
#   %clone : Tensor "f16[1, 8, 4, 512, 128][2097152, 262144, 65536, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view_12 : Tensor "f16[1, 32, 512, 128][2097152, 65536, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 32, 512, 128]), kwargs = {})
#   %mul_6 : Tensor "f16[1, 32, 512, 128][2097152, 65536, 128, 1]spyre:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_12, 0.08838834764831845), kwargs = {})
#   %permute_4 : Tensor "f16[1, 32, 128, 512][2097152, 65536, 1, 128]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_6, [0, 1, 3, 2]), kwargs = {})
#   %batched_matmul_default_1 : Tensor "f16[1, 32, 512, 512][8388608, 262144, 512, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.spyre.batched_matmul.default](args = (%expand_4, %expand_5), kwargs = {})
#   %unsqueeze_5 : Tensor "f16[1, 1, 512, 512][262144, 262144, 512, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 1), kwargs = {})
#   %add_1 : Tensor "f16[1, 32, 512, 512][8388608, 262144, 512, 1]spyre:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%batched_matmul_default_1, %unsqueeze_5), kwargs = {})
#   %amax : Tensor "f16[1, 32, 512, 1][16384, 512, 1, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add_1, [-1], True), kwargs = {})
#   %sub : Tensor "f16[1, 32, 512, 512][8388608, 262144, 512, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add_1, %amax), kwargs = {})
#   %exp : Tensor "f16[1, 32, 512, 512][8388608, 262144, 512, 1]spyre:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %sum_3 : Tensor "f16[1, 32, 512, 1][16384, 512, 1, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   %div : Tensor "f16[1, 32, 512, 512][8388608, 262144, 512, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_3), kwargs = {})
#   %view_5 : Tensor "f16[1, 512, 8, 128][3145728, 6144, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_2, [1, 512, 8, 128]), kwargs = {})
#   %permute_2 : Tensor "f16[1, 8, 512, 128][3145728, 128, 6144, 1]spyre:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze_7 : Tensor "f16[1, 8, 1, 512, 128][3145728, 128, 3145728, 6144, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_2, 2), kwargs = {})
#   %expand_3 : Tensor "f16[1, 8, 4, 512, 128][3145728, 128, 0, 6144, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [-1, -1, 4, -1, -1]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 8, 4, 512, 128][2097152, 262144, 65536, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_13 : Tensor "f16[1, 32, 512, 128][2097152, 65536, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 32, 512, 128]), kwargs = {})
#   %batched_matmul_default : Tensor "f16[1, 32, 512, 128][2097152, 65536, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.spyre.batched_matmul.default](args = (%expand_6, %expand_7), kwargs = {})
#   %permute_5 : Tensor "f16[1, 512, 32, 128][2097152, 128, 65536, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%batched_matmul_default, [0, 2, 1, 3]), kwargs = {})
#   %clone_2 : Tensor "f16[1, 512, 32, 128][2097152, 4096, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_5,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_5,%mul_3,%sum_1,%expand_4,%mul_4,%sum_2,%clone_3,%clone,%mul_6,%restickify_default_1,%buf14,%add_1,%amax,%sub,%exp,%sum_3,%expand_6,%clone_1,%batched_matmul_default,%clone_2
sdsc_fused__scaled_dot_product_fused_attention_overrideable__unsafe_view_clone_expand_mul_split_with_sizes_sum_transpose_unsqueeze_view_1 = async_compile.sdsc('sdsc_fused__scaled_dot_product_fused_attention_overrideable__unsafe_view_clone_expand_mul_split_with_sizes_sum_transpose_unsqueeze_view_1',
    [
        OpSpec(
            op='identity',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 1), sympify('c1'): (sympify('2'), 1), sympify('c2'): (sympify('2'), 1), sympify('c3'): (sympify('64'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=0, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 2, 2, 64],
                    device_coordinates=[sympify('floor(c3/64)'), sympify('c0'), sympify('c1'), sympify('c2'), sympify('Mod(c3, 64)')],
                    allocation={'hbm': 17179869184},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 2, 2, 64],
                    device_coordinates=[sympify('floor(c3/64)'), sympify('c0'), sympify('c1'), sympify('c2'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('d0'): (sympify('512'), 32), sympify('d1'): (sympify('32'), 1), sympify('d2'): (sympify('2'), 1), sympify('d3'): (sympify('64'), 1), sympify('d4'): (sympify('2'), 1)},
            op_info={'lx_relayout_classifications': {'buf6': {'source_name': 'buf6', 'producer_name': 'buf6', 'consumer_name': 'buf7', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0, '1': 0}, '1': {'0': 1, '1': 0}, '2': {'0': 2, '1': 0}, '3': {'0': 3, '1': 0}, '4': {'0': 0, '1': 1}, '5': {'0': 1, '1': 1}, '6': {'0': 2, '1': 1}, '7': {'0': 3, '1': 1}, '8': {'0': 0, '1': 2}, '9': {'0': 1, '1': 2}, '10': {'0': 2, '1': 2}, '11': {'0': 3, '1': 2}, '12': {'0': 0, '1': 3}, '13': {'0': 1, '1': 3}, '14': {'0': 2, '1': 3}, '15': {'0': 3, '1': 3}, '16': {'0': 0, '1': 4}, '17': {'0': 1, '1': 4}, '18': {'0': 2, '1': 4}, '19': {'0': 3, '1': 4}, '20': {'0': 0, '1': 5}, '21': {'0': 1, '1': 5}, '22': {'0': 2, '1': 5}, '23': {'0': 3, '1': 5}, '24': {'0': 0, '1': 6}, '25': {'0': 1, '1': 6}, '26': {'0': 2, '1': 6}, '27': {'0': 3, '1': 6}, '28': {'0': 0, '1': 7}, '29': {'0': 1, '1': 7}, '30': {'0': 2, '1': 7}, '31': {'0': 3, '1': 7}}, 'producer_work_slice_dims': {'0': 4, '1': 8}, 'consumer_work_slice_dims': {'0': 32}, 'read_index': 1, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 512, 2, 2, 64],
                    device_coordinates=[sympify('floor(d3/64)'), sympify('0'), sympify('d0'), sympify('d2'), sympify('d4'), sympify('Mod(d3, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 512, 48, 2, 64],
                    device_coordinates=[sympify('floor(d3/64)'), sympify('0'), sympify('d0'), sympify('d1'), sympify('d4'), sympify('Mod(d3, 64)')],
                    allocation={'hbm': 34359738368},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 32, 2, 2, 512, 64],
                    device_coordinates=[sympify('floor(d3/64)'), sympify('d1'), sympify('d2'), sympify('d4'), sympify('d0'), sympify('Mod(d3, 64)')],
                    allocation={'lx': 262144},
                ),
            ]
        ),
        OpSpec(
            op='sum',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('32'), 1), sympify('c2'): (sympify('2'), 1), sympify('c3'): (sympify('64'), 1), sympify('c4'): (sympify('2'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 32, 2, 2, 512, 64],
                    device_coordinates=[sympify('floor(c3/64)'), sympify('c1'), sympify('c2'), sympify('c4'), sympify('c0'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 32, 2, 512, 64],
                    device_coordinates=[sympify('floor(c3/64)'), sympify('0'), sympify('c1'), sympify('c2'), sympify('c0'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 524288},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('32'), 1), sympify('c2'): (sympify('128'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[32, 2, 512, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 524288},
                ),
                TensorArg(
                    is_input=True, arg_index=2, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 1, 64],
                    device_coordinates=[sympify('0'), sympify('0'), sympify('0'), sympify('0')],
                    allocation={'hbm': 51539607552},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 2, 32, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c2/64)'), sympify('c1'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 655360},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('d0'): (sympify('512'), 32), sympify('d1'): (sympify('8'), 1), sympify('d2'): (sympify('2'), 1), sympify('d3'): (sympify('64'), 1), sympify('d4'): (sympify('2'), 1)},
            op_info={'lx_relayout_classifications': {'buf6': {'source_name': 'buf6', 'producer_name': 'buf6', 'consumer_name': 'buf10', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0, '1': 0}, '1': {'0': 1, '1': 0}, '2': {'0': 2, '1': 0}, '3': {'0': 3, '1': 0}, '4': {'0': 0, '1': 1}, '5': {'0': 1, '1': 1}, '6': {'0': 2, '1': 1}, '7': {'0': 3, '1': 1}, '8': {'0': 0, '1': 2}, '9': {'0': 1, '1': 2}, '10': {'0': 2, '1': 2}, '11': {'0': 3, '1': 2}, '12': {'0': 0, '1': 3}, '13': {'0': 1, '1': 3}, '14': {'0': 2, '1': 3}, '15': {'0': 3, '1': 3}, '16': {'0': 0, '1': 4}, '17': {'0': 1, '1': 4}, '18': {'0': 2, '1': 4}, '19': {'0': 3, '1': 4}, '20': {'0': 0, '1': 5}, '21': {'0': 1, '1': 5}, '22': {'0': 2, '1': 5}, '23': {'0': 3, '1': 5}, '24': {'0': 0, '1': 6}, '25': {'0': 1, '1': 6}, '26': {'0': 2, '1': 6}, '27': {'0': 3, '1': 6}, '28': {'0': 0, '1': 7}, '29': {'0': 1, '1': 7}, '30': {'0': 2, '1': 7}, '31': {'0': 3, '1': 7}}, 'producer_work_slice_dims': {'0': 4, '1': 8}, 'consumer_work_slice_dims': {'0': 32}, 'read_index': 1, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 512, 2, 2, 64],
                    device_coordinates=[sympify('floor(d3/64)'), sympify('0'), sympify('d0'), sympify('d2'), sympify('d4'), sympify('Mod(d3, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 512, 48, 2, 64],
                    device_coordinates=[sympify('floor(d3/64)'), sympify('0'), sympify('d0'), sympify('d1 + 32'), sympify('d4'), sympify('Mod(d3, 64)')],
                    allocation={'hbm': 34359738368},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 8, 2, 2, 512, 64],
                    device_coordinates=[sympify('floor(d3/64)'), sympify('d1'), sympify('d2'), sympify('d4'), sympify('d0'), sympify('Mod(d3, 64)')],
                    allocation={'lx': 786432},
                ),
            ]
        ),
        OpSpec(
            op='sum',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('8'), 1), sympify('c2'): (sympify('2'), 1), sympify('c3'): (sympify('64'), 1), sympify('c4'): (sympify('2'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 8, 2, 2, 512, 64],
                    device_coordinates=[sympify('floor(c3/64)'), sympify('c1'), sympify('c2'), sympify('c4'), sympify('c0'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 786432},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 8, 2, 512, 64],
                    device_coordinates=[sympify('floor(c3/64)'), sympify('0'), sympify('c1'), sympify('c2'), sympify('c0'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='identity',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('8'), 1), sympify('c2'): (sympify('2'), 1), sympify('c3'): (sympify('64'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 8, 2, 512, 64],
                    device_coordinates=[sympify('floor(c3/64)'), sympify('c1'), sympify('c2'), sympify('c0'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=False, arg_index=4, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 8, 2, 512, 64],
                    device_coordinates=[sympify('floor(c3/64)'), sympify('c1'), sympify('c2'), sympify('c0'), sympify('Mod(c3, 64)')],
                    allocation={'hbm': 85899345920},
                ),
            ]
        ),
        OpSpec(
            op='identity',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('8'), 1), sympify('c1'): (sympify('4'), 1), sympify('c2'): (sympify('512'), 32), sympify('c3'): (sympify('128'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 8, 2, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('floor(c3/64)'), sympify('c2'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[8, 4, 512, 2, 64],
                    device_coordinates=[sympify('c0'), sympify('c1'), sympify('c2'), sympify('floor(c3/64)'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 786432},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('32'), 1), sympify('c1'): (sympify('512'), 32), sympify('c2'): (sympify('128'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[32, 512, 2, 64],
                    device_coordinates=[sympify('c0'), sympify('c1'), sympify('floor(c2/64)'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 786432},
                ),
                TensorArg(
                    is_input=True, arg_index=2, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 1, 64],
                    device_coordinates=[sympify('0'), sympify('0'), sympify('0'), sympify('0')],
                    allocation={'hbm': 51539607552},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 2, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='ReStickifyOpHBM',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('32'), 32), sympify('c1'): (sympify('512'), 1), sympify('c2'): (sympify('128'), 1)},
            op_info={'lx_relayout_classifications': {'buf13': {'source_name': 'buf13', 'producer_name': 'buf13', 'consumer_name': 'buf46', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}, '25': {'0': 25}, '26': {'0': 26}, '27': {'0': 27}, '28': {'0': 28}, '29': {'0': 29}, '30': {'0': 30}, '31': {'0': 31}}, 'producer_work_slice_dims': {'0': 32}, 'consumer_work_slice_dims': {'3': 32}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 2, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 0},
                    lx_residency_core_id_to_wk_slice={'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}, '25': {'0': 25}, '26': {'0': 26}, '27': {'0': 27}, '28': {'0': 28}, '29': {'0': 29}, '30': {'0': 30}, '31': {'0': 31}},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[128, 8, 32, 64],
                    device_coordinates=[sympify('c2'), sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 786432},
                ),
            ]
        ),
        OpSpec(
            op='batchmatmul',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 16), sympify('c1'): (sympify('32'), 1), sympify('c2'): (sympify('512'), 2), sympify('c3'): (sympify('128'), 1)},
            op_info={'lx_relayout_classifications': {'buf9': {'source_name': 'buf9', 'producer_name': 'buf9', 'consumer_name': 'buf14', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}, '25': {'0': 25}, '26': {'0': 26}, '27': {'0': 27}, '28': {'0': 28}, '29': {'0': 29}, '30': {'0': 30}, '31': {'0': 31}}, 'producer_work_slice_dims': {'0': 32}, 'consumer_work_slice_dims': {'0': 16}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}, 'buf46': {'source_name': 'buf46', 'producer_name': 'buf46', 'consumer_name': 'buf14', 'kind': 'layout_restickify_activation', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'3': 0}, '1': {'3': 1}, '2': {'3': 2}, '3': {'3': 3}, '4': {'3': 4}, '5': {'3': 5}, '6': {'3': 6}, '7': {'3': 7}, '8': {'3': 8}, '9': {'3': 9}, '10': {'3': 10}, '11': {'3': 11}, '12': {'3': 12}, '13': {'3': 13}, '14': {'3': 14}, '15': {'3': 15}, '16': {'3': 16}, '17': {'3': 17}, '18': {'3': 18}, '19': {'3': 19}, '20': {'3': 20}, '21': {'3': 21}, '22': {'3': 22}, '23': {'3': 23}, '24': {'3': 24}, '25': {'3': 25}, '26': {'3': 26}, '27': {'3': 27}, '28': {'3': 28}, '29': {'3': 29}, '30': {'3': 30}, '31': {'3': 31}}, 'producer_work_slice_dims': {'3': 32}, 'consumer_work_slice_dims': {'2': 2}, 'read_index': 1, 'realized': True, 'communication_pattern': 'layout_transform_then_operand_broadcast', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 2, 32, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c3/64)'), sympify('c1'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 655360},
                    lx_residency_core_id_to_wk_slice={'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}, '25': {'0': 25}, '26': {'0': 26}, '27': {'0': 27}, '28': {'0': 28}, '29': {'0': 29}, '30': {'0': 30}, '31': {'0': 31}},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[128, 8, 32, 64],
                    device_coordinates=[sympify('c3'), sympify('floor(c2/64)'), sympify('c1'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 786432},
                    lx_residency_core_id_to_wk_slice={'0': {'3': 0}, '1': {'3': 1}, '2': {'3': 2}, '3': {'3': 3}, '4': {'3': 4}, '5': {'3': 5}, '6': {'3': 6}, '7': {'3': 7}, '8': {'3': 8}, '9': {'3': 9}, '10': {'3': 10}, '11': {'3': 11}, '12': {'3': 12}, '13': {'3': 13}, '14': {'3': 14}, '15': {'3': 15}, '16': {'3': 16}, '17': {'3': 17}, '18': {'3': 18}, '19': {'3': 19}, '20': {'3': 20}, '21': {'3': 21}, '22': {'3': 22}, '23': {'3': 23}, '24': {'3': 24}, '25': {'3': 25}, '26': {'3': 26}, '27': {'3': 27}, '28': {'3': 28}, '29': {'3': 29}, '30': {'3': 30}, '31': {'3': 31}},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[32, 512, 8, 64],
                    device_coordinates=[sympify('c1'), sympify('c0'), sympify('floor(c2/64)'), sympify('Mod(c2, 64)')],
                    allocation={'pool': 4194304},
                ),
            ]
        ),
        OpSpec(
            op='add',
            is_reduction=False,
            iteration_space={sympify('d0'): (sympify('32'), 1), sympify('d1'): (sympify('512'), 32), sympify('d2'): (sympify('512'), 1)},
            op_info={'lx_relayout_classifications': {'buf14': {'source_name': 'buf14', 'producer_name': 'buf14', 'consumer_name': 'buf15', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'1': 0, '2': 0}, '1': {'1': 1, '2': 0}, '2': {'1': 2, '2': 0}, '3': {'1': 3, '2': 0}, '4': {'1': 4, '2': 0}, '5': {'1': 5, '2': 0}, '6': {'1': 6, '2': 0}, '7': {'1': 7, '2': 0}, '8': {'1': 8, '2': 0}, '9': {'1': 9, '2': 0}, '10': {'1': 10, '2': 0}, '11': {'1': 11, '2': 0}, '12': {'1': 12, '2': 0}, '13': {'1': 13, '2': 0}, '14': {'1': 14, '2': 0}, '15': {'1': 15, '2': 0}, '16': {'1': 0, '2': 1}, '17': {'1': 1, '2': 1}, '18': {'1': 2, '2': 1}, '19': {'1': 3, '2': 1}, '20': {'1': 4, '2': 1}, '21': {'1': 5, '2': 1}, '22': {'1': 6, '2': 1}, '23': {'1': 7, '2': 1}, '24': {'1': 8, '2': 1}, '25': {'1': 9, '2': 1}, '26': {'1': 10, '2': 1}, '27': {'1': 11, '2': 1}, '28': {'1': 12, '2': 1}, '29': {'1': 13, '2': 1}, '30': {'1': 14, '2': 1}, '31': {'1': 15, '2': 1}}, 'producer_work_slice_dims': {'1': 16, '2': 2}, 'consumer_work_slice_dims': {'1': 32}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[32, 512, 8, 64],
                    device_coordinates=[sympify('d0'), sympify('d1'), sympify('floor(d2/64)'), sympify('Mod(d2, 64)')],
                    allocation={'pool': 4194304},
                ),
                TensorArg(
                    is_input=True, arg_index=3, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 8, 64],
                    device_coordinates=[sympify('0'), sympify('d1'), sympify('floor(d2/64)'), sympify('Mod(d2, 64)')],
                    allocation={'hbm': 68719476736},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('d1'), sympify('floor(d2/64)'), sympify('d0'), sympify('Mod(d2, 64)')],
                    allocation={'lx': 262144},
                ),
            ]
        ),
        OpSpec(
            op='max',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('32'), 1), sympify('c1'): (sympify('512'), 32), sympify('c2'): (sympify('512'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 32, 64],
                    device_coordinates=[sympify('0'), sympify('c1'), sympify('c0'), sympify('0')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='sub',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('32'), 1), sympify('c1'): (sympify('512'), 32), sympify('c2'): (sympify('512'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 32, 64],
                    device_coordinates=[sympify('0'), sympify('c1'), sympify('c0'), sympify('0')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 786432},
                ),
            ]
        ),
        OpSpec(
            op='exp',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('32'), 1), sympify('c1'): (sympify('512'), 32), sympify('c2'): (sympify('512'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 786432},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 786432},
                ),
            ]
        ),
        OpSpec(
            op='sum',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('32'), 1), sympify('c1'): (sympify('512'), 32), sympify('c2'): (sympify('512'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 786432},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 32, 64],
                    device_coordinates=[sympify('0'), sympify('c1'), sympify('c0'), sympify('0')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='realdiv',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('32'), 1), sympify('c1'): (sympify('512'), 32), sympify('c2'): (sympify('512'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 786432},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 32, 64],
                    device_coordinates=[sympify('0'), sympify('c1'), sympify('c0'), sympify('0')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 786432},
                ),
            ]
        ),
        OpSpec(
            op='identity',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('8'), 1), sympify('c1'): (sympify('4'), 1), sympify('c2'): (sympify('512'), 32), sympify('c3'): (sympify('128'), 1)},
            op_info={'lx_relayout_classifications': {'buf6': {'source_name': 'buf6', 'producer_name': 'buf6', 'consumer_name': 'buf21', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0, '1': 0}, '1': {'0': 1, '1': 0}, '2': {'0': 2, '1': 0}, '3': {'0': 3, '1': 0}, '4': {'0': 0, '1': 1}, '5': {'0': 1, '1': 1}, '6': {'0': 2, '1': 1}, '7': {'0': 3, '1': 1}, '8': {'0': 0, '1': 2}, '9': {'0': 1, '1': 2}, '10': {'0': 2, '1': 2}, '11': {'0': 3, '1': 2}, '12': {'0': 0, '1': 3}, '13': {'0': 1, '1': 3}, '14': {'0': 2, '1': 3}, '15': {'0': 3, '1': 3}, '16': {'0': 0, '1': 4}, '17': {'0': 1, '1': 4}, '18': {'0': 2, '1': 4}, '19': {'0': 3, '1': 4}, '20': {'0': 0, '1': 5}, '21': {'0': 1, '1': 5}, '22': {'0': 2, '1': 5}, '23': {'0': 3, '1': 5}, '24': {'0': 0, '1': 6}, '25': {'0': 1, '1': 6}, '26': {'0': 2, '1': 6}, '27': {'0': 3, '1': 6}, '28': {'0': 0, '1': 7}, '29': {'0': 1, '1': 7}, '30': {'0': 2, '1': 7}, '31': {'0': 3, '1': 7}}, 'producer_work_slice_dims': {'0': 4, '1': 8}, 'consumer_work_slice_dims': {'0': 32}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 48, 2, 64],
                    device_coordinates=[sympify('0'), sympify('c2'), sympify('c0 + 40'), sympify('floor(c3/64)'), sympify('Mod(c3, 64)')],
                    allocation={'hbm': 34359738368},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[8, 4, 512, 2, 64],
                    device_coordinates=[sympify('c0'), sympify('c1'), sympify('c2'), sympify('floor(c3/64)'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='batchmatmul',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('32'), 1), sympify('c1'): (sympify('512'), 32), sympify('c2'): (sympify('128'), 1), sympify('c3'): (sympify('512'), 1)},
            op_info={'lx_relayout_classifications': {'buf21': {'source_name': 'buf21', 'producer_name': 'buf21', 'consumer_name': 'buf22', 'kind': 'matmul_operand_broadcast', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'2': 0}, '1': {'2': 1}, '2': {'2': 2}, '3': {'2': 3}, '4': {'2': 4}, '5': {'2': 5}, '6': {'2': 6}, '7': {'2': 7}, '8': {'2': 8}, '9': {'2': 9}, '10': {'2': 10}, '11': {'2': 11}, '12': {'2': 12}, '13': {'2': 13}, '14': {'2': 14}, '15': {'2': 15}, '16': {'2': 16}, '17': {'2': 17}, '18': {'2': 18}, '19': {'2': 19}, '20': {'2': 20}, '21': {'2': 21}, '22': {'2': 22}, '23': {'2': 23}, '24': {'2': 24}, '25': {'2': 25}, '26': {'2': 26}, '27': {'2': 27}, '28': {'2': 28}, '29': {'2': 29}, '30': {'2': 30}, '31': {'2': 31}}, 'producer_work_slice_dims': {'2': 32}, 'consumer_work_slice_dims': {}, 'read_index': 1, 'realized': True, 'communication_pattern': 'all_gather_replicate', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 8, 32, 64],
                    device_coordinates=[sympify('c1'), sympify('floor(c3/64)'), sympify('c0'), sympify('Mod(c3, 64)')],
                    allocation={'lx': 786432},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[32, 512, 2, 64],
                    device_coordinates=[sympify('c0'), sympify('c3'), sympify('floor(c2/64)'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 0},
                    lx_residency_core_id_to_wk_slice={'0': {'2': 0}, '1': {'2': 1}, '2': {'2': 2}, '3': {'2': 3}, '4': {'2': 4}, '5': {'2': 5}, '6': {'2': 6}, '7': {'2': 7}, '8': {'2': 8}, '9': {'2': 9}, '10': {'2': 10}, '11': {'2': 11}, '12': {'2': 12}, '13': {'2': 13}, '14': {'2': 14}, '15': {'2': 15}, '16': {'2': 16}, '17': {'2': 17}, '18': {'2': 18}, '19': {'2': 19}, '20': {'2': 20}, '21': {'2': 21}, '22': {'2': 22}, '23': {'2': 23}, '24': {'2': 24}, '25': {'2': 25}, '26': {'2': 26}, '27': {'2': 27}, '28': {'2': 28}, '29': {'2': 29}, '30': {'2': 30}, '31': {'2': 31}},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[32, 512, 2, 64],
                    device_coordinates=[sympify('c0'), sympify('c1'), sympify('floor(c2/64)'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 1310720},
                ),
            ]
        ),
        OpSpec(
            op='identity',
            is_reduction=False,
            iteration_space={sympify('d0'): (sympify('32'), 1), sympify('d1'): (sympify('512'), 32), sympify('d2'): (sympify('128'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[32, 512, 2, 64],
                    device_coordinates=[sympify('d0'), sympify('d1'), sympify('floor(d2/64)'), sympify('Mod(d2, 64)')],
                    allocation={'lx': 1310720},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 32, 2, 64],
                    device_coordinates=[sympify('d1'), sympify('d0'), sympify('floor(d2/64)'), sympify('Mod(d2, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
    ]
)


# Topologically Sorted Source Nodes: [attn, attn_1, attn_2, out, mul_2, x_1, x_2, out_fused, split_1, silu, out_1], Original ATen: [aten._scaled_dot_product_fused_attention_overrideable, aten.transpose, aten.view, aten.linear, aten.mul, aten.add, aten.rms_norm, aten.split_with_sizes, aten.silu]
# Source node to ATen node mapping:
#   attn => permute_6
#   attn_1 => permute_7
#   attn_2 => view_20
#   mul_2 => mul_7
#   out => bmm_3, permute_8, unsqueeze_8, view_21, view_22
#   out_1 => mul_11
#   out_fused => bmm_4, permute_9, unsqueeze_9, view_25
#   silu => silu
#   split_1 => split_with_sizes_1
#   x_1 => add_2
#   x_2 => add_3, mean_1, mul_10, mul_8, mul_9, rsqrt_1
# Graph fragment:
#   %arg5_1 : Tensor "f16[4096, 4096][4096, 1]spyre:0" = PlaceHolder[target=arg5_1]
#   %clone_2 : Tensor "f16[1, 512, 32, 128][2097152, 4096, 128, 1]spyre:0" = PlaceHolder[target=clone_2]
#   %restickify_default_2 : Tensor "f16[4096, 4096][4096, 1]spyre:0" = PlaceHolder[target=restickify_default_2]
#   %buf24 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=buf24]
#   %constant_default_3 : Tensor "f16[][]spyre:0" = PlaceHolder[target=constant_default_3]
#   %mul_7 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=mul_7]
#   %clone_4 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=clone_4]
#   %add_2 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=add_2]
#   %mul_8 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=mul_8]
#   %mean_1 : Tensor "f16[1, 512, 1][512, 1, 512]spyre:0" = PlaceHolder[target=mean_1]
#   %constant_default : Tensor "f16[][]spyre:0" = PlaceHolder[target=constant_default]
#   %add_3 : Tensor "f16[1, 512, 1][512, 1, 512]spyre:0" = PlaceHolder[target=add_3]
#   %rsqrt_1 : Tensor "f16[1, 512, 1][512, 1, 512]spyre:0" = PlaceHolder[target=rsqrt_1]
#   %mul_9 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=mul_9]
#   %arg6_1 : Tensor "f16[4096][1]spyre:0" = PlaceHolder[target=arg6_1]
#   %arg7_1 : Tensor "f16[25600, 4096][4096, 1]spyre:0" = PlaceHolder[target=arg7_1]
#   %view_24 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=view_24]
#   %restickify_default_3 : Tensor "f16[25600, 4096][4096, 1]spyre:0" = PlaceHolder[target=restickify_default_3]
#   %buf33 : Tensor "f16[1, 512, 25600][13107200, 25600, 1]spyre:0" = PlaceHolder[target=buf33]
#   %silu : Tensor "f16[1, 512, 12800][6553600, 12800, 1]spyre:0" = PlaceHolder[target=silu]
#   %restickify_default_3 : [num_users=0] = call_function[target=torch.ops.spyre.restickify.default](args = (%arg7_1,), kwargs = {})
#   %restickify_default_2 : [num_users=0] = call_function[target=torch.ops.spyre.restickify.default](args = (%arg5_1,), kwargs = {})
#   %permute_6 : Tensor "f16[1, 32, 512, 128][2097152, 128, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%clone_2, [0, 2, 1, 3]), kwargs = {})
#   %permute_7 : Tensor "f16[1, 512, 32, 128][2097152, 4096, 128, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%permute_6, [0, 2, 1, 3]), kwargs = {})
#   %view_20 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%permute_7, [1, 512, 4096]), kwargs = {})
#   %view_21 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_8, [1, 512, 4096]), kwargs = {})
#   %permute_8 : Tensor "f16[4096, 4096][1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg5_1, [1, 0]), kwargs = {})
#   %unsqueeze_8 : Tensor "f16[1, 4096, 4096][4096, 1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_8, 0), kwargs = {})
#   %view_22 : Tensor "f16[1, 4096, 4096][4096, 1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_9, [1, 4096, 4096]), kwargs = {})
#   %bmm_3 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_21, %view_22), kwargs = {})
#   %mul_7 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_23, 0.22), kwargs = {})
#   %add_2 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_7, %clone_4), kwargs = {})
#   %mul_8 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_2, %add_2), kwargs = {})
#   %mean_1 : Tensor "f16[1, 512, 1][512, 1, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%mul_8, [-1], True), kwargs = {})
#   %add_3 : Tensor "f16[1, 512, 1][512, 1, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-05), kwargs = {})
#   %rsqrt_1 : Tensor "f16[1, 512, 1][512, 1, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3,), kwargs = {})
#   %mul_9 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_2, %rsqrt_1), kwargs = {})
#   %mul_10 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_9, %arg6_1), kwargs = {})
#   %permute_9 : Tensor "f16[4096, 25600][1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg7_1, [1, 0]), kwargs = {})
#   %unsqueeze_9 : Tensor "f16[1, 4096, 25600][4096, 1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_9, 0), kwargs = {})
#   %view_25 : Tensor "f16[1, 4096, 25600][4096, 1, 4096]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_11, [1, 4096, 25600]), kwargs = {})
#   %bmm_4 : Tensor "f16[1, 512, 25600][13107200, 25600, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_24, %view_25), kwargs = {})
#   %split_with_sizes_1 : [num_users=2] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%view_26, [12800, 12800], 2), kwargs = {})
#   %silu : Tensor "f16[1, 512, 12800][6553600, 12800, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.spyre.silu.default](args = (%getitem_3,), kwargs = {})
#   %mul_11 : Tensor "f16[1, 512, 12800][6553600, 12800, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%silu, %getitem_4), kwargs = {})
#   return %restickify_default_2,%buf24,%mul_7,%add_2,%mul_8,%mean_1,%add_3,%rsqrt_1,%mul_9,%view_24,%restickify_default_3,%buf33,%silu,%view_27
sdsc_fused__scaled_dot_product_fused_attention_overrideable_add_linear_mul_rms_norm_silu_split_with_sizes_transpose_view_2 = async_compile.sdsc('sdsc_fused__scaled_dot_product_fused_attention_overrideable_add_linear_mul_rms_norm_silu_split_with_sizes_transpose_view_2',
    [
        OpSpec(
            op='ReStickifyOpHBM',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('4096'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=0, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 4096, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 17179869184},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 4096, 64],
                    device_coordinates=[sympify('floor(c0/64)'), sympify('c1'), sympify('Mod(c0, 64)')],
                    allocation={'pool': 20971520},
                ),
            ]
        ),
        OpSpec(
            op='batchmatmul',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 4), sympify('c1'): (sympify('4096'), 8), sympify('c2'): (sympify('4096'), 1)},
            op_info={'lx_relayout_classifications': {'buf23': {'source_name': 'buf23', 'producer_name': 'buf23', 'consumer_name': 'buf24', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}, '25': {'0': 25}, '26': {'0': 26}, '27': {'0': 27}, '28': {'0': 28}, '29': {'0': 29}, '30': {'0': 30}, '31': {'0': 31}}, 'producer_work_slice_dims': {'0': 32}, 'consumer_work_slice_dims': {'0': 4}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}, 'buf47': {'source_name': 'buf47', 'producer_name': 'buf47', 'consumer_name': 'buf24', 'kind': 'layout_restickify_weight', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}, '25': {'0': 25}, '26': {'0': 26}, '27': {'0': 27}, '28': {'0': 28}, '29': {'0': 29}, '30': {'0': 30}, '31': {'0': 31}}, 'producer_work_slice_dims': {'0': 32}, 'consumer_work_slice_dims': {'0': 8}, 'read_index': 1, 'realized': False, 'communication_pattern': 'offline_weight_prelayout', 'unsupported_reason': 'graph-input/parameter restickify is owned by offline weight prelayout, not runtime LX relayout'}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c2/64)'), sympify('Mod(c2, 64)')],
                    allocation={'lx': 0},
                    lx_residency_core_id_to_wk_slice={'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}, '25': {'0': 25}, '26': {'0': 26}, '27': {'0': 27}, '28': {'0': 28}, '29': {'0': 29}, '30': {'0': 30}, '31': {'0': 31}},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 4096, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c2'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 20971520},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 0},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={'lx_relayout_classifications': {'buf24': {'source_name': 'buf24', 'producer_name': 'buf24', 'consumer_name': 'buf25', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0, '1': 0}, '1': {'0': 1, '1': 0}, '2': {'0': 2, '1': 0}, '3': {'0': 3, '1': 0}, '4': {'0': 0, '1': 1}, '5': {'0': 1, '1': 1}, '6': {'0': 2, '1': 1}, '7': {'0': 3, '1': 1}, '8': {'0': 0, '1': 2}, '9': {'0': 1, '1': 2}, '10': {'0': 2, '1': 2}, '11': {'0': 3, '1': 2}, '12': {'0': 0, '1': 3}, '13': {'0': 1, '1': 3}, '14': {'0': 2, '1': 3}, '15': {'0': 3, '1': 3}, '16': {'0': 0, '1': 4}, '17': {'0': 1, '1': 4}, '18': {'0': 2, '1': 4}, '19': {'0': 3, '1': 4}, '20': {'0': 0, '1': 5}, '21': {'0': 1, '1': 5}, '22': {'0': 2, '1': 5}, '23': {'0': 3, '1': 5}, '24': {'0': 0, '1': 6}, '25': {'0': 1, '1': 6}, '26': {'0': 2, '1': 6}, '27': {'0': 3, '1': 6}, '28': {'0': 0, '1': 7}, '29': {'0': 1, '1': 7}, '30': {'0': 2, '1': 7}, '31': {'0': 3, '1': 7}}, 'producer_work_slice_dims': {'0': 4, '1': 8}, 'consumer_work_slice_dims': {'0': 32}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 64],
                    device_coordinates=[sympify('0'), sympify('0'), sympify('0')],
                    allocation={'hbm': 34359738368},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='add',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
            ]
        ),
        OpSpec(
            op='mean',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={'constants': {'scaling_factor': 0.000244140625}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
            ]
        ),
        OpSpec(
            op='add',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=True, arg_index=2, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 64],
                    device_coordinates=[sympify('0'), sympify('0'), sympify('0')],
                    allocation={'hbm': 51539607552},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
            ]
        ),
        OpSpec(
            op='rsqrt',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 512, 64],
                    device_coordinates=[sympify('0'), sympify('c0'), sympify('0')],
                    allocation={'lx': 262144},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 264192},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 264192},
                ),
                TensorArg(
                    is_input=True, arg_index=3, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 64, 64],
                    device_coordinates=[sympify('0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 68719476736},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 4194304},
                ),
            ]
        ),
        OpSpec(
            op='ReStickifyOpHBM',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('25600'), 25), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=4, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 25600, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 85899345920},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[400, 4096, 64],
                    device_coordinates=[sympify('floor(c0/64)'), sympify('c1'), sympify('Mod(c0, 64)')],
                    allocation={'pool': 54525952},
                ),
            ]
        ),
        OpSpec(
            op='batchmatmul',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 4), sympify('c1'): (sympify('25600'), 8), sympify('c2'): (sympify('4096'), 1)},
            op_info={'lx_relayout_classifications': {'buf32': {'source_name': 'buf32', 'producer_name': 'buf32', 'consumer_name': 'buf33', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'2': 0}, '1': {'2': 1}, '2': {'2': 2}, '3': {'2': 3}, '4': {'2': 4}, '5': {'2': 5}, '6': {'2': 6}, '7': {'2': 7}, '8': {'2': 8}, '9': {'2': 9}, '10': {'2': 10}, '11': {'2': 11}, '12': {'2': 12}, '13': {'2': 13}, '14': {'2': 14}, '15': {'2': 15}, '16': {'2': 16}, '17': {'2': 17}, '18': {'2': 18}, '19': {'2': 19}, '20': {'2': 20}, '21': {'2': 21}, '22': {'2': 22}, '23': {'2': 23}, '24': {'2': 24}, '25': {'2': 25}, '26': {'2': 26}, '27': {'2': 27}, '28': {'2': 28}, '29': {'2': 29}, '30': {'2': 30}, '31': {'2': 31}}, 'producer_work_slice_dims': {'2': 32}, 'consumer_work_slice_dims': {'2': 4}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}, 'buf48': {'source_name': 'buf48', 'producer_name': 'buf48', 'consumer_name': 'buf33', 'kind': 'layout_restickify_weight', 'producer_core_count': 25, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0}, '1': {'0': 1}, '2': {'0': 2}, '3': {'0': 3}, '4': {'0': 4}, '5': {'0': 5}, '6': {'0': 6}, '7': {'0': 7}, '8': {'0': 8}, '9': {'0': 9}, '10': {'0': 10}, '11': {'0': 11}, '12': {'0': 12}, '13': {'0': 13}, '14': {'0': 14}, '15': {'0': 15}, '16': {'0': 16}, '17': {'0': 17}, '18': {'0': 18}, '19': {'0': 19}, '20': {'0': 20}, '21': {'0': 21}, '22': {'0': 22}, '23': {'0': 23}, '24': {'0': 24}}, 'producer_work_slice_dims': {'0': 25}, 'consumer_work_slice_dims': {'0': 8}, 'read_index': 1, 'realized': False, 'communication_pattern': 'offline_weight_prelayout', 'unsupported_reason': 'graph-input/parameter restickify is owned by offline weight prelayout, not runtime LX relayout'}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 512, 64],
                    device_coordinates=[sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'pool': 4194304},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[400, 4096, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c2'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 54525952},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 400, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 20971520},
                ),
            ]
        ),
        OpSpec(
            op='silu',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('12800'), 1)},
            op_info={'lx_relayout_classifications': {'buf33': {'source_name': 'buf33', 'producer_name': 'buf33', 'consumer_name': 'buf34', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0, '1': 0}, '1': {'0': 1, '1': 0}, '2': {'0': 2, '1': 0}, '3': {'0': 3, '1': 0}, '4': {'0': 0, '1': 1}, '5': {'0': 1, '1': 1}, '6': {'0': 2, '1': 1}, '7': {'0': 3, '1': 1}, '8': {'0': 0, '1': 2}, '9': {'0': 1, '1': 2}, '10': {'0': 2, '1': 2}, '11': {'0': 3, '1': 2}, '12': {'0': 0, '1': 3}, '13': {'0': 1, '1': 3}, '14': {'0': 2, '1': 3}, '15': {'0': 3, '1': 3}, '16': {'0': 0, '1': 4}, '17': {'0': 1, '1': 4}, '18': {'0': 2, '1': 4}, '19': {'0': 3, '1': 4}, '20': {'0': 0, '1': 5}, '21': {'0': 1, '1': 5}, '22': {'0': 2, '1': 5}, '23': {'0': 3, '1': 5}, '24': {'0': 0, '1': 6}, '25': {'0': 1, '1': 6}, '26': {'0': 2, '1': 6}, '27': {'0': 3, '1': 6}, '28': {'0': 0, '1': 7}, '29': {'0': 1, '1': 7}, '30': {'0': 2, '1': 7}, '31': {'0': 3, '1': 7}}, 'producer_work_slice_dims': {'0': 4, '1': 8}, 'consumer_work_slice_dims': {'0': 32}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 400, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 20971520},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[200, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('12800'), 1)},
            op_info={'lx_relayout_classifications': {'buf33': {'source_name': 'buf33', 'producer_name': 'buf33', 'consumer_name': 'buf35', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0, '1': 0}, '1': {'0': 1, '1': 0}, '2': {'0': 2, '1': 0}, '3': {'0': 3, '1': 0}, '4': {'0': 0, '1': 1}, '5': {'0': 1, '1': 1}, '6': {'0': 2, '1': 1}, '7': {'0': 3, '1': 1}, '8': {'0': 0, '1': 2}, '9': {'0': 1, '1': 2}, '10': {'0': 2, '1': 2}, '11': {'0': 3, '1': 2}, '12': {'0': 0, '1': 3}, '13': {'0': 1, '1': 3}, '14': {'0': 2, '1': 3}, '15': {'0': 3, '1': 3}, '16': {'0': 0, '1': 4}, '17': {'0': 1, '1': 4}, '18': {'0': 2, '1': 4}, '19': {'0': 3, '1': 4}, '20': {'0': 0, '1': 5}, '21': {'0': 1, '1': 5}, '22': {'0': 2, '1': 5}, '23': {'0': 3, '1': 5}, '24': {'0': 0, '1': 6}, '25': {'0': 1, '1': 6}, '26': {'0': 2, '1': 6}, '27': {'0': 3, '1': 6}, '28': {'0': 0, '1': 7}, '29': {'0': 1, '1': 7}, '30': {'0': 2, '1': 7}, '31': {'0': 3, '1': 7}}, 'producer_work_slice_dims': {'0': 4, '1': 8}, 'consumer_work_slice_dims': {'0': 32}, 'read_index': 1, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[200, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 400, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64) + 200'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 20971520},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[200, 512, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 54525952},
                ),
            ]
        ),
    ]
)


# Topologically Sorted Source Nodes: [x_3, mul_4, x_4], Original ATen: [aten.linear, aten.mul, aten.add]
# Source node to ATen node mapping:
#   mul_4 => mul_12
#   x_3 => bmm_5, permute_10, unsqueeze_10, view_28
#   x_4 => add_4
# Graph fragment:
#   %arg8_1 : Tensor "f16[4096, 12800][12800, 1]spyre:0" = PlaceHolder[target=arg8_1]
#   %view_27 : Tensor "f16[1, 512, 12800][6553600, 12800, 1]spyre:0" = PlaceHolder[target=view_27]
#   %restickify_default_4 : Tensor "f16[4096, 12800][12800, 1]spyre:0" = PlaceHolder[target=restickify_default_4]
#   %buf36 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=buf36]
#   %constant_default_3 : Tensor "f16[][]spyre:0" = PlaceHolder[target=constant_default_3]
#   %mul_12 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=mul_12]
#   %add_2 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0" = PlaceHolder[target=add_2]
#   %restickify_default_4 : [num_users=0] = call_function[target=torch.ops.spyre.restickify.default](args = (%arg8_1,), kwargs = {})
#   %permute_10 : Tensor "f16[12800, 4096][1, 12800]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg8_1, [1, 0]), kwargs = {})
#   %unsqueeze_10 : Tensor "f16[1, 12800, 4096][12800, 1, 12800]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_10, 0), kwargs = {})
#   %view_28 : Tensor "f16[1, 12800, 4096][12800, 1, 12800]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_13, [1, 12800, 4096]), kwargs = {})
#   %bmm_5 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_27, %view_28), kwargs = {})
#   %mul_12 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_29, 0.22), kwargs = {})
#   %add_4 : Tensor "f16[1, 512, 4096][2097152, 4096, 1]spyre:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_12, %add_2), kwargs = {})
#   return %restickify_default_4,%buf36,%mul_12,%add_4
sdsc_fused_add_linear_mul_3 = async_compile.sdsc('sdsc_fused_add_linear_mul_3',
    [
        OpSpec(
            op='ReStickifyOpHBM',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('4096'), 1), sympify('c1'): (sympify('12800'), 25)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=0, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[200, 4096, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c0'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 17179869184},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 12800, 64],
                    device_coordinates=[sympify('floor(c0/64)'), sympify('c1'), sympify('Mod(c0, 64)')],
                    allocation={'pool': 67633152},
                ),
            ]
        ),
        OpSpec(
            op='batchmatmul',
            is_reduction=True,
            iteration_space={sympify('c0'): (sympify('512'), 8), sympify('c1'): (sympify('4096'), 4), sympify('c2'): (sympify('12800'), 1)},
            op_info={'lx_relayout_classifications': {'buf35': {'source_name': 'buf35', 'producer_name': 'buf35', 'consumer_name': 'buf36', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'2': 0}, '1': {'2': 1}, '2': {'2': 2}, '3': {'2': 3}, '4': {'2': 4}, '5': {'2': 5}, '6': {'2': 6}, '7': {'2': 7}, '8': {'2': 8}, '9': {'2': 9}, '10': {'2': 10}, '11': {'2': 11}, '12': {'2': 12}, '13': {'2': 13}, '14': {'2': 14}, '15': {'2': 15}, '16': {'2': 16}, '17': {'2': 17}, '18': {'2': 18}, '19': {'2': 19}, '20': {'2': 20}, '21': {'2': 21}, '22': {'2': 22}, '23': {'2': 23}, '24': {'2': 24}, '25': {'2': 25}, '26': {'2': 26}, '27': {'2': 27}, '28': {'2': 28}, '29': {'2': 29}, '30': {'2': 30}, '31': {'2': 31}}, 'producer_work_slice_dims': {'2': 32}, 'consumer_work_slice_dims': {'2': 8}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}, 'buf49': {'source_name': 'buf49', 'producer_name': 'buf49', 'consumer_name': 'buf36', 'kind': 'layout_restickify_weight', 'producer_core_count': 25, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'1': 0}, '1': {'1': 1}, '2': {'1': 2}, '3': {'1': 3}, '4': {'1': 4}, '5': {'1': 5}, '6': {'1': 6}, '7': {'1': 7}, '8': {'1': 8}, '9': {'1': 9}, '10': {'1': 10}, '11': {'1': 11}, '12': {'1': 12}, '13': {'1': 13}, '14': {'1': 14}, '15': {'1': 15}, '16': {'1': 16}, '17': {'1': 17}, '18': {'1': 18}, '19': {'1': 19}, '20': {'1': 20}, '21': {'1': 21}, '22': {'1': 22}, '23': {'1': 23}, '24': {'1': 24}}, 'producer_work_slice_dims': {'1': 25}, 'consumer_work_slice_dims': {'0': 4}, 'read_index': 1, 'realized': False, 'communication_pattern': 'offline_weight_prelayout', 'unsupported_reason': 'graph-input/parameter restickify is owned by offline weight prelayout, not runtime LX relayout'}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[200, 512, 64],
                    device_coordinates=[sympify('floor(c2/64)'), sympify('c0'), sympify('Mod(c2, 64)')],
                    allocation={'pool': 54525952},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[64, 12800, 64],
                    device_coordinates=[sympify('floor(c1/64)'), sympify('c2'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 67633152},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 0},
                ),
            ]
        ),
        OpSpec(
            op='mul',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={'lx_relayout_classifications': {'buf36': {'source_name': 'buf36', 'producer_name': 'buf36', 'consumer_name': 'buf37', 'kind': 'scatter', 'producer_core_count': 32, 'consumer_core_count': 32, 'producer_core_id_to_device_slice': {'0': {'0': 0, '1': 0}, '1': {'0': 1, '1': 0}, '2': {'0': 2, '1': 0}, '3': {'0': 3, '1': 0}, '4': {'0': 4, '1': 0}, '5': {'0': 5, '1': 0}, '6': {'0': 6, '1': 0}, '7': {'0': 7, '1': 0}, '8': {'0': 0, '1': 1}, '9': {'0': 1, '1': 1}, '10': {'0': 2, '1': 1}, '11': {'0': 3, '1': 1}, '12': {'0': 4, '1': 1}, '13': {'0': 5, '1': 1}, '14': {'0': 6, '1': 1}, '15': {'0': 7, '1': 1}, '16': {'0': 0, '1': 2}, '17': {'0': 1, '1': 2}, '18': {'0': 2, '1': 2}, '19': {'0': 3, '1': 2}, '20': {'0': 4, '1': 2}, '21': {'0': 5, '1': 2}, '22': {'0': 6, '1': 2}, '23': {'0': 7, '1': 2}, '24': {'0': 0, '1': 3}, '25': {'0': 1, '1': 3}, '26': {'0': 2, '1': 3}, '27': {'0': 3, '1': 3}, '28': {'0': 4, '1': 3}, '29': {'0': 5, '1': 3}, '30': {'0': 6, '1': 3}, '31': {'0': 7, '1': 3}}, 'producer_work_slice_dims': {'0': 8, '1': 4}, 'consumer_work_slice_dims': {'0': 32}, 'read_index': 0, 'realized': True, 'communication_pattern': '', 'unsupported_reason': ''}}},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'pool': 0},
                ),
                TensorArg(
                    is_input=True, arg_index=1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[1, 1, 64],
                    device_coordinates=[sympify('0'), sympify('0'), sympify('0')],
                    allocation={'hbm': 34359738368},
                ),
                TensorArg(
                    is_input=False, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
            ]
        ),
        OpSpec(
            op='add',
            is_reduction=False,
            iteration_space={sympify('c0'): (sympify('512'), 32), sympify('c1'): (sympify('4096'), 1)},
            op_info={},
            symbolic_dim_bounds={},
            args=[
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 131072},
                ),
                TensorArg(
                    is_input=True, arg_index=-1, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'lx': 0},
                ),
                TensorArg(
                    is_input=False, arg_index=2, device_dtype=DataFormats.SEN169_FP16,
                    device_size=[512, 64, 64],
                    device_coordinates=[sympify('c0'), sympify('floor(c1/64)'), sympify('Mod(c1, 64)')],
                    allocation={'hbm': 51539607552},
                ),
            ]
        ),
    ]
)


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1 = args
        args.clear()
        buf39 = spyre_constant_tensor(1e-05, torch.device("spyre:0"), torch.float16)
        buf40 = spyre_constant_tensor(0.08838834764831845, torch.device("spyre:0"), torch.float16)
        buf42 = spyre_constant_tensor(0.22, torch.device("spyre:0"), torch.float16)
        assert_size_stride(arg1_1, (1, 512, 4096), (2097152, 4096, 1))
        assert_size_stride(arg0_1, (4096, ), (1, ))
        assert_size_stride(arg2_1, (6144, 4096), (4096, 1))
        buf6 = spyre_empty_with_layout((1, 512, 6144), (3145728, 6144, 1), torch.float16, SpyreTensorLayout(device_size=[512, 96, 1, 64], stride_map =[6144, 64, -1, 1], device_dtype=DataFormats.SEN169_FP16))
        _pool = spyre_empty_with_layout((2064384,), (1,), torch.uint8, SpyreTensorLayout(device_size=[2064384, 1, 1], stride_map=[1, 1, 1], device_dtype=DataFormats.SENINT8))
        sdsc_fused_linear_rms_norm_0.run(_pool, arg1_1, buf39, arg0_1, arg2_1, buf6)
        del arg0_1
        del arg1_1
        del arg2_1
        assert_size_stride(arg3_1, (1, 512, 2, 2, 64), (131072, 256, 128, 64, 1))
        assert_size_stride(arg4_1, (1, 512, 512), (262144, 512, 1))
        buf50 = spyre_empty_with_layout((1, 512, 8, 2, 1, 64), (524288, 1024, 128, 64, 64, 1), torch.float16, SpyreTensorLayout(device_size=[8, 2, 1, 1, 1, 512, 64], stride_map =[128, 64, -1, -1, 64, 1024, 1], device_dtype=DataFormats.SEN169_FP16))
        sdsc_fused__scaled_dot_product_fused_attention_overrideable__unsafe_view_clone_expand_mul_split_with_sizes_sum_transpose_unsqueeze_view_1.run(_pool, arg3_1, buf6, buf40, arg4_1, buf50)
        del arg3_1
        del arg4_1
        del buf40
        assert_size_stride(arg5_1, (4096, 4096), (4096, 1))
        assert_size_stride(arg6_1, (4096, ), (1, ))
        assert_size_stride(arg7_1, (25600, 4096), (4096, 1))
        sdsc_fused__scaled_dot_product_fused_attention_overrideable_add_linear_mul_rms_norm_silu_split_with_sizes_transpose_view_2.run(_pool, arg5_1, buf42, buf39, arg6_1, arg7_1)
        del arg5_1
        del arg6_1
        del arg7_1
        del buf39
        assert_size_stride(arg8_1, (4096, 12800), (12800, 1))
        buf38 = spyre_empty_with_layout((1, 512, 4096), (2097152, 4096, 1), torch.float16, SpyreTensorLayout(device_size=[512, 64, 1, 64], stride_map =[4096, 64, -1, 1], device_dtype=DataFormats.SEN169_FP16))
        sdsc_fused_add_linear_mul_3.run(_pool, arg8_1, buf42, buf38)
        del arg8_1
        del _pool
        return (buf38, reinterpret_tensor(buf50, (1, 8, 512, 128), (524288, 128, 1024, 1), 0), reinterpret_tensor(buf6, (1, 8, 512, 128), (3145728, 128, 6144, 1), 5120), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns
