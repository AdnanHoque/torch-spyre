# Restickify LX evidence - 2026-06-30

Run: `/home/adnan/codex-isolated/20260630_190544/runs/granite_prefill_restickify_lx_agent_20260630_192254`

## Measurements

- median wall ms: `31.861305236816406`
- kernel ms per iter: `12.048442999999999`
- memory ms per iter: `0.3565086666666667`

## Op counts

- `ReStickifyOpHBM`: 5
- `batchmatmul`: 6
- `identity`: 6

## Classification counts

- `layout_restickify_activation`: 1
- `layout_restickify_weight`: 4
- `matmul_operand_broadcast`: 1
- `scatter`: 14

## Classification realized counts

- `layout_restickify_activation` realized=false: 1
- `layout_restickify_weight` realized=false: 4
- `matmul_operand_broadcast` realized=false: 1
- `scatter` realized=true: 14

## Target rows

- `layout_restickify_activation` | `sdsc_fused__scaled_dot_product_fused_attention_overrideable__unsafe_view_clone_expand_mul_split_with_sizes_sum_transpose_unsqueeze_view_1_6bnw7eld/sdsc_10.json` | op `batchmatmul` | source `buf46` | realized `False` | pattern `layout_transform_then_operand_broadcast` | reason `computed activation restickify needs an LX layout restickify contract plus loop-scoped matmul operand lowering`
- `matmul_operand_broadcast` | `sdsc_fused__scaled_dot_product_fused_attention_overrideable__unsafe_view_clone_expand_mul_split_with_sizes_sum_transpose_unsqueeze_view_1_6bnw7eld/sdsc_18.json` | op `batchmatmul` | source `buf21` | realized `False` | pattern `all_gather_replicate` | reason `non-primary matmul operands need loop-scoped collective lowering, not resident scatter materialization`

## Result

- `ReStickifyOpLx` count: `0`
- `ReStickifyOpHBM` count: `5`
- The activation restickify marker reached generated code, but the OpSpec output allocation is `pool`, not `lx`; the narrow guard intentionally left it as HBM.
