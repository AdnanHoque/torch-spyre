import json, pathlib, re, sys, collections

def walk(o):
    if isinstance(o, dict):
        yield o
        for v in o.values():
            yield from walk(v)
    elif isinstance(o, list):
        for v in o:
            yield from walk(v)

def load(path):
    try:
        return json.loads(path.read_text())
    except Exception:
        return None

def opname(d, p):
    if isinstance(d, dict) and len(d) == 1:
        return next(iter(d.keys()))
    keys = ["opName_", "opName", "opfuncName_", "opfuncName", "funcName_", "name_", "op_", "op"]
    vals = []
    for obj in walk(d):
        for k in keys:
            v = obj.get(k)
            if isinstance(v, str):
                vals.append(v)
    for v in vals:
        if any(x in v for x in ["ReStickifyOpHBM", "batchmatmul", "amax", "exp", "mul", "realdiv", "add", "sub", "maximum", "sum", "div"]):
            return v
    return vals[0] if vals else p.stem

def loc_counts_text(txt):
    # Count tensor allocation objects by location token. This is tensor-count style, not byte-count style.
    out = {}
    for loc in ["hbm", "lx", "pool"]:
        out[loc] = len(re.findall(r'"' + loc + r'"\s*:', txt)) + len(re.findall(r'allocation=\[' + loc + r'=', txt))
    return out

def relayout_counts(d):
    c = collections.Counter()
    for obj in walk(d):
        for k, v in obj.items():
            kl = str(k).lower()
            if "relayout" not in kl and "communication" not in kl:
                continue
            if isinstance(v, str):
                c[v] += 1
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, dict):
                        kind = item.get("kind") or item.get("communication_class") or item.get("communication_pattern") or item.get("type")
                        if kind:
                            c[str(kind)] += 1
                    elif isinstance(item, str):
                        c[item] += 1
            elif isinstance(v, dict):
                kind = v.get("kind") or v.get("communication_class") or v.get("communication_pattern") or v.get("type")
                if kind:
                    c[str(kind)] += 1
    return c

def summarize(run):
    root = pathlib.Path(run)
    files = [pathlib.Path(x.strip()) for x in (root / "sdsc_files.txt").read_text().splitlines() if x.strip()]
    op_counter = collections.Counter()
    alloc = collections.Counter()
    relayout = collections.Counter()
    bundles = collections.Counter()
    examples = []
    for p in files:
        txt = p.read_text(errors="ignore")
        d = load(p)
        if d is None:
            continue
        op = opname(d, p)
        op_counter[op] += 1
        bundles[p.parent.name] += 1
        alloc.update(loc_counts_text(txt))
        relayout.update(relayout_counts(d))
        if "ReStickifyOpHBM" in txt and len(examples) < 50:
            examples.append(str(p))
    out = {
        "run": str(root),
        "rc": (root / "returncode.txt").read_text().strip() if (root / "returncode.txt").exists() else None,
        "sdsc_count": len(files),
        "bundle_count": len(bundles),
        "op_counts_top": op_counter.most_common(80),
        "restickify_hbm_text_count": sum(1 for p in files if "ReStickifyOpHBM" in p.read_text(errors="ignore")),
        "alloc_counts": dict(alloc),
        "relayout_counts": dict(relayout),
        "bundle_counts": dict(bundles),
        "restickify_examples": examples,
    }
    print(json.dumps(out, indent=2, sort_keys=True))

for run in sys.argv[1:]:
    summarize(run)
