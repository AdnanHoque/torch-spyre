import json, pathlib, re, collections
runs = {
    "baseline": "/home/adnan/codex-isolated/flash-sdsc-20260701-033044/runs/baseline_noh2d_20260701_040758",
    "optimized": "/home/adnan/codex-isolated/flash-sdsc-20260701-033044/runs/optimized_noh2d_20260701_041326",
}
def baseop(k):
    if "_" in k and k.split("_", 1)[0].isdigit():
        return k.split("_", 1)[1]
    return k
out = {}
for name, run in runs.items():
    root = pathlib.Path(run)
    files = [pathlib.Path(x.strip()) for x in (root / "sdsc_files.txt").read_text().splitlines() if x.strip()]
    c = collections.Counter()
    bundles = collections.Counter()
    rest = []
    lxmeta = 0
    relayout_keys = collections.Counter()
    alloc_loc = collections.Counter()
    for p in files:
        txt = p.read_text(errors="ignore")
        d = json.loads(txt)
        key = next(iter(d))
        c[baseop(key)] += 1
        bundles[p.parent.name] += 1
        if "ReStickifyOpHBM" in txt or baseop(key) == "ReStickifyOpHBM":
            rest.append(str(p))
        if "lx_residency_core_id_to_wk_slice" in txt:
            lxmeta += 1
        for m in re.finditer(r'"allocLocation_"\s*:\s*"([^"]+)"', txt):
            alloc_loc[m.group(1)] += 1
        for m in re.finditer(r'"component_"\s*:\s*"([^"]+)"', txt):
            alloc_loc["component:" + m.group(1)] += 1
        for m in re.finditer(r'"(hbm|lx|pool)_"', txt):
            alloc_loc["tensor:" + m.group(1)] += 1
        for m in re.finditer(r'"([^"]*(?:relayout|communication)[^"]*)"\s*:', txt, re.I):
            relayout_keys[m.group(1)] += 1
    out[name] = {
        "run": run,
        "rc": (root / "returncode.txt").read_text().strip() if (root / "returncode.txt").exists() else None,
        "sdsc_files": len(files),
        "bundles": len(bundles),
        "restickify_hbm_rows": len(rest),
        "lx_residency_text_files": lxmeta,
        "op_class_counts": c.most_common(),
        "alloc_loc_counts": alloc_loc.most_common(),
        "relayout_keys": relayout_keys.most_common(),
        "restickify_examples": rest[:20],
    }
print(json.dumps(out, indent=2, sort_keys=True))
