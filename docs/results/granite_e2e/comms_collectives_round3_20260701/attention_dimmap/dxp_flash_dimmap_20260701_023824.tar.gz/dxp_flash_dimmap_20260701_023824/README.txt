DXP dim-mapping repro for test_flash.py scatter lane
created: 2026-07-01T02:44:25+00:00
source run: /home/adnan/codex-isolated/flash_main_probe_20260701_015234/runs/scatter_singleton_patch_noskip_20260701_022026
source bundle: /home/adnan/codex-isolated/dxp_flash_dimmap_20260701_023824/scatter_full_bundle
minimal failing scatter bundle: /home/adnan/codex-isolated/dxp_flash_dimmap_20260701_023824/scatter_sdsc6_bundle
matching baseline failing bundle: /home/adnan/codex-isolated/dxp_flash_dimmap_20260701_023824/baseline_single6_bundle

Environment command:
  export PATH=/home/adnan/codex-isolated/flash_main_probe_20260701_015234/setup/tools/dxp-split-wrapper-current:/home/adnan/dt-inductor/sentient/runtime/bin:/home/adnan/dt-inductor/sentient/deeptools/bin:/opt/ibm/spyre/deeptools/bin:/home/adnan/dt-inductor/.venv/bin:/home/adnan/.local/bin:/home/adnan/bin:/opt/ibm/spyre/tvm/bin:/opt/ibm/spyre/spyre-comms/bin:/opt/ibm/spyre/runtime/bin:/opt/ibm/spyre/deeptools/bin:/opt/ibm/spyre/senlib/bin:/opt/ibm/spyre/sentinyexec/bin:/usr/lib64/ccache:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
  export LD_LIBRARY_PATH=/opt/ibm/spyre/deeptools/lib:/opt/ibm/spyre/runtime/lib:/opt/ibm/spyre/spyre-comms/lib:/home/adnan/dt-inductor/build/libaiupti/lib:/home/adnan/dt-inductor/.venv/lib/python3.12/site-packages/torch/lib:/home/adnan/dt-inductor/sentient/libaiupti/lib:/home/adnan/dt-inductor/sentient/runtime/lib:/home/adnan/dt-inductor/sentient/deeptools/lib:/opt/ibm/spyre/runtime/lib:/opt/ibm/spyre/spyre-comms/lib:/opt/ibm/spyre/deeptools/lib:/opt/ibm/spyre/senlib/lib:/home/adnan/dt-inductor/.venv/lib/python3.12/site-packages/torch/lib:/home/adnan/dt-inductor/sentient/libaiupti/lib
  export DXP_BACKEND_LX_FRAC_AVAIL=1 DXP_LX_FRAC_AVAIL=0 SPYRE_LX_PLANNER_RELAYOUT=1 LX_BOUNDARY_CLONES=1
  dxp_standalone --bundle -d /home/adnan/codex-isolated/dxp_flash_dimmap_20260701_023824/scatter_sdsc6_bundle

Observed:
  scatter sdsc_6 rc=134
  baseline sdsc_6 rc=134
  only sdsc_83 rc=0
  without sdsc_83 rc=134

First failing SDSC in bundle order: sdsc_6.json -> 6_ReStickifyOpHBM.
All individual failing SDSCs are listed in individual_sdsc_scan.tsv.
